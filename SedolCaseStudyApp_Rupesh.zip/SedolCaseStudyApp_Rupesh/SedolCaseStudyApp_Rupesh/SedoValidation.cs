﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SedolCaseStudyApp_Rupesh
{
    public class SedoValidation : ISedolValidator
    {
       

        public ISedolValidationResult ValidateSedol(string input)
        {

            //TODO- if input contains aphabet then have to convert in to number with +9 from position is pending.
            ISedolValidationResult obj = new SedolValidationResult();

            if (string.IsNullOrEmpty(input) || input.Length != 7)
            {
                obj.IsValidSedol = false;
                obj.IsUserDefined = false;
                obj.ValidationDetails = "Input string was not 7-characters long";
                obj.InputString = input;

            }
            else if (Convert.ToInt32(input[input.Length - 1].ToString()) != CheckDigit(CalculatecheckSum(input)))
            {
                obj.IsValidSedol = false;
                obj.IsUserDefined = false;
                obj.ValidationDetails = "Checksum digit does not agree with the rest of the input";
                obj.InputString = input;
            }
            else if (Convert.ToInt32(input[input.Length-1].ToString()) == CheckDigit(CalculatecheckSum(input)))
            {
                obj.IsValidSedol = true;
                obj.IsUserDefined = false;
                obj.ValidationDetails = string.Empty;
                obj.InputString = input;
            } else if (new Regex("[^A-Z0-9.$ ]$").IsMatch(input))
            {            

                obj.IsValidSedol = false;
                obj.IsUserDefined = false;
                obj.ValidationDetails = "SEDOL contains invalid characters";
                obj.InputString = input;
            }
            return obj;
        }

        private int CalculatecheckSum(string input)
        {
            int checkSum=0;
            var inputStringArray = new char[7];

            var weightingFactor = new int[6] {1,3,1,7,3,9 };



            inputStringArray = input.ToCharArray();

            for (int i = 0; i < input.Length-1; i++)
            {
                checkSum = checkSum + (Convert.ToInt32(inputStringArray[i].ToString()) * weightingFactor[i]);
            }
            return checkSum;

        }

        private int CheckDigit(int checkSum)
        {
            return  (10 - (checkSum % 10)) % 10;            
        }
    }
}
