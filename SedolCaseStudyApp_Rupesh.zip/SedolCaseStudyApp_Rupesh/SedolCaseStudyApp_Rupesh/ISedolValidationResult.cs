﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SedolCaseStudyApp_Rupesh
{
    public interface ISedolValidationResult
    {
        string InputString { get; set; }
        bool IsValidSedol { get; set; }
        bool IsUserDefined { get; set; }
        string ValidationDetails { get; set; }
    }
}
