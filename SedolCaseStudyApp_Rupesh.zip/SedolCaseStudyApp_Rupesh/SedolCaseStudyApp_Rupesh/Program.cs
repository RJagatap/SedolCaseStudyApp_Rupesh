﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SedolCaseStudyApp_Rupesh
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Input SEDOL string to validate");
            var sedolString = Console.ReadLine();
            ISedolValidator obj = new SedoValidation();
            var result = obj.ValidateSedol(sedolString);
            Console.WriteLine("Entered SEDOL Value - " + result.InputString);
            Console.WriteLine("IsValid SEDOL - "+ result.IsValidSedol);       
            if(!string.IsNullOrEmpty(result.ValidationDetails))
            Console.WriteLine("Validation MEssage - "+result.ValidationDetails);
            Console.Read();

        }
    }
}
